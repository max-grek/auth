module Main where

main :: IO ()
main = print "huy"
